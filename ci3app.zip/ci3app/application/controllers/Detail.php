<?php

class Detail extends CI_Controller

{
    public function index()
    {
        $data['judul'] = 'Mang Engking';
        $this->load->view('templates/header', $data);
        $this->load->view('detail/mangengking');
        $this->load->view('templates/footer');
    }

    public function kabayan()
    {
        $data['judul'] = 'Mang Engking';
        $this->load->view('templates/header', $data);
        $this->load->view('detail/kabayan');
        $this->load->view('templates/footer');
    }

    public function talaga()
    {
        $data['judul'] = 'Mang Engking';
        $this->load->view('templates/header', $data);
        $this->load->view('detail/talaga');
        $this->load->view('templates/footer');
    }

    public function kubah()
    {
        $data['judul'] = 'Mang Engking';
        $this->load->view('templates/header', $data);
        $this->load->view('detail/kubah');
        $this->load->view('templates/footer');
    }

    public function kebun()
    {
        $data['judul'] = 'Mang Engking';
        $this->load->view('templates/header', $data);
        $this->load->view('detail/kebun');
        $this->load->view('templates/footer');
    }

    public function taman()
    {
        $data['judul'] = 'Mang Engking';
        $this->load->view('templates/header', $data);
        $this->load->view('detail/taman');
        $this->load->view('templates/footer');
    }
}
