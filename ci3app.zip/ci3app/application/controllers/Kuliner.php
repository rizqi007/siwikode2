<?php

class Kuliner extends CI_Controller
{
    public function index()
    {
        $data['judul'] = 'Wisata Kuliner';
        $this->load->view('templates/header', $data);
        $this->load->view('siwikode/kuliner');
        $this->load->view('templates/footer');
    }
}
