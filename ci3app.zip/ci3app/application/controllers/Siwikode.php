<?php

class Siwikode extends CI_Controller

{
    public function index()
    {
        $data['judul'] = 'Our Team';
        $this->load->view('templates/header', $data);
        $this->load->view('siwikode/ourteam');
        $this->load->view('templates/footer');
    }
}
