<?php

class Rekreasi extends CI_Controller
{
    public function index()
    {
        $data['judul'] = 'Wisata Rekreasi';
        $this->load->view('templates/header', $data);
        $this->load->view('siwikode/rekreasi');
        $this->load->view('templates/footer');
    }
}
