<?php

class Mahasiswa_model extends CI_Model
{
    public function getAllMahasiswa()
    {
        // return $this->db->get('mahasiswa')->resultArray();
        $query = $this->db->get('mahasiswa');
        return $query->result_Array();
    }

    public function tambahDataMahasiswa()
    {
        $data = [
            "nama" => $this->input->post('nama'),
            "nim" => $this->input->post('nim'),
            "email" => $this->input->post('email'),
            "jurusan" => $this->input->post('jurusan')

        ];

        $this->db->insert('mahasiswa', $data);
    }

    public function hapusDataMahasiswa($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('mahasiswa');
    }
}
