<!-- ======= Why Us Section ======= -->
<section id="why-us" class="why-us">
    <br><br>
    <h2 class="p">Daftar wisata Kuliner Kota depok</h2>
    <br>
    <div class="container-fluid">


        <div class="container">
            <section class="row1">
                <div class="row ml-2">

                    <div class="col-md-4 mt-5">
                        <img class="card-img-top" alt="Bootstrap Thumbnail First" src="<?= base_url(); ?>assets/img/kuliner/download (2).jpeg" />
                    </div>

                    <div class="col-md-7 mr-2">
                        <h3>
                            Mang kabayan
                        </h3>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        </br>
                        <p>
                            Pemilihan nama Mang Kabayan nggak sembarangan karena mengandung tujuan untuk memperkuat ciri khas Sunda
                            pada restoran ini. Tidak hanya namanya yang menonjolkan khas Sunda, seluruh fasilitasnya pun sengaja
                            didesain bertemakan budaya Sunda. Sehingga konsumen datang ke restoran ini bisa merasakan nuansa Sunda
                            yang kental seperti yang diceritakan dalam dongeng Si Kabayan. Disini banyak fasilitas yang memadai dan
                            tertata rapi.
                        </p>
                        <div>
                            <a href="<?= base_url(); ?>detail/kabayan" class="more-btn1">Detail<i class="bx bx-chevron-right"></i></a>
                        </div>
                    </div>
                </div>
            </section>
        </div>
</section>



<div class="container">
    <section class="row1">
        <div class="row ">

            <div class="col-md-4 mt-5 mb-5">
                <img class="card-img-top" alt="Bootstrap Thumbnail First" src="<?= base_url(); ?>assets/img/kuliner/download (3).jpeg " />
            </div>

            <div class="col-md-7 mr-2">
                <h3>
                    Mang Engking
                </h3>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>

                </br>
                <p>
                    Untuk Anda yang tinggal di Jakarta, tidak perlu lagi kebingungan untuk menemukan gubug makan Mang
                    Engking
                    Jakarta.
                    Makan bersama dengan keluarga merupakan saat yang dinanti dan berarti untuk setiap orang.
                    Menghabiskan
                    waktu bersama dengan keluarga merupakan salah satu cara untuk meningkatkan semangat dan juga
                    keakraban
                    anggota keluarga.
                </p>
                <div>
                    <a href="<?= base_url(); ?>detail" class="more-btn1">Detail<i class="bx bx-chevron-right"></i></a>
                </div>
            </div>
        </div>
    </section>
</div>
</section>

<section id="why-us" class="why-us">
    <div class="container">
        <section class="row1">
            <div class="row ml-2">

                <div class="col-md-4 mt-5 mb-5 mr-4">
                    <img class="card-img-top" alt="Bootstrap Thumbnail First" src="<?= base_url(); ?>assets/img/kuliner/download (4).jpeg" />
                </div>

                <div class="col-md-7 mr-2">
                    <h3>
                        Saung Talaga
                    </h3>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>

                    </br>
                    <p>
                        Dekat dengan Jakarta, Depok, ternyata punya tempat makan yang bisa disambangi bersama keluarga.
                        Lokasinya
                        di Jalan Raya Sawangan, sekitar 20 menit dari stasiun Depok Baru.
                        Saung Talaga menyediakan sajian khas Sunda dan Jawa. Diantaranya ragam olahan ikan gurame, ikan mas,
                        udang, ayam bakar, dan sop iga. Pilihan sayurnya juga beragam seperti kangkung, sayur asem, sayur bayam dll.
                    </p>
                    <div>
                        <a href="<?= base_url(); ?>detail/talaga" class="more-btn1">Detail<i class="bx bx-chevron-right"></i></a>
                    </div>
                </div>
            </div>
        </section>
    </div>
</section>




<!-- End Section -->