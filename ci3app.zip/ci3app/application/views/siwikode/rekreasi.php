<!-- ======= Why Us Section ======= -->
<section id="why-us" class="why-us">
    <br><br>
    <h2 class="p">Daftar wisata Rekreasi Kota depok</h2>
    <br>
    <div class="container-fluid">


        <div class="container">
            <section class="row1">
                <div class="row ml-2">

                    <div class="col-md-4 mt-5 mb-5">
                        <img class="card-img-top" alt="Bootstrap Thumbnail First" src="<?= base_url(); ?>assets/img/kubah.jpeg " />
                    </div>

                    <div class="col-md-7 mr-2">
                        <h3>
                            Kubah Emas
                        </h3>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>

                        </br>
                        <p>
                            Masjid Dian Al Mahri memiliki 5 kubah. Satu kubah utama dan 4 kubah kecil. Uniknya, seluruh kubah dilapisi emas setebal 2 sampai 3 milimeter dan mozaik kristal. Bentuk kubah utama menyerupai kubah Taj Mahal. Kubah tersebut memiliki diameter bawah 16 meter, diameter tengah 20 meter, dan tinggi 25 meter. Sementara 4 kubah kecil memiliki diameter bawah 6 meter, tengah 7 meter, dan tinggi 8 meter.
                        </p>
                        <div>
                            <a href="<?= base_url(); ?>detail/kubah" class="more-btn1">Detail<i class="bx bx-chevron-right"></i></a>
                        </div>
                    </div>
                </div>
            </section>
        </div>
</section>



<div class="container">
    <section class="row1">
        <div class="row ">

            <div class="col-md-4 mt-5 mb-5 ">
                <img class="card-img-top" alt="Bootstrap Thumbnail First" src="<?= base_url(); ?>assets/img/download.jpg " />
            </div>

            <div class="col-md-7 mr-2">
                <h3>
                    Kebun Raya Bogor
                </h3>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>

                </br>
                <p>
                    Kebun Raya Bogor atau Kebun Botani Bogor adalah
                    sebuah kebun botani besar yang terletak di Kota Bogor, Indonesia. Luasnya mencapai 87 hektar dan
                    memiliki 15.000 jenis koleksi pohon dan tumbuhan.Di sekitar Kebun Raya Bogor tersebar pusat-pusat
                    keilmuan yaitu Museum Zoologi Bogor, dan PUSTAKA.
                    Monumen Olivia Raffles
                    Pada tahun 1814 Olivia Raffles (istri dari Gubernur Jenderal Thomas Stamford Raffles) meninggal dunia karena sakit dan dimakamkan di Batavia.
                </p>
                <div>
                    <a href="<?= base_url(); ?>detail/kebun" class="more-btn1">Detail<i class="bx bx-chevron-right"></i></a>
                </div>
            </div>
        </div>
    </section>
</div>
</section>

<section id="why-us" class="why-us">
    <div class="container">
        <section class="row1">
            <div class="row ml-2">

                <div class="col-md-4 mt-5 mb-5 mr-4">
                    <img class="card-img-top" alt="Bootstrap Thumbnail First" src="<?= base_url(); ?>assets/img/download (1).jpeg" />
                </div>

                <div class="col-md-7 mr-2">
                    <h3>
                        Taman wiladatika
                    </h3>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>

                    </br>
                    <p>
                        Taman Rekreasi Wiladatika Cibubur merupakan tempat wisata yang berlokasi di Cimanggis, Depok Jawa Barat. Di sini terdapat Pusat Pendidikan dan Pelatihan Pramuka Nasional (Pusdiklatmas), aula resepsi yang biasa digunakan untuk acara resepsi pernikahan, dan halaman hijau yang biasa di gunakan para pengunjung untuk piknik bersama keluarga, ketika acara besar pramuka biasa digunakan untuk berkemah.
                    </p>
                    <div>
                        <a href="<?= base_url(); ?>detail/taman" class="more-btn1">Detail<i class="bx bx-chevron-right"></i></a>
                    </div>
                </div>
            </div>
        </section>
    </div>
</section>




<!-- End Section -->