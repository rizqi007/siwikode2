<!-- ======= Top Bar ======= -->
<div id="topbar" class="d-none d-lg-flex align-items-center fixed-top">
    <div class="container d-flex">
        <div class="contact-info mr-auto">
            <i class="icofont-envelope"></i> <a href="mailto:contact@example.com">smait@nurulfikri.sch.id</a>
            <i class="icofont-phone">085866874974</i>
            <i class="icofont-google-map">Jakarta Selatan</i>
        </div>

        <div class="social-links">
            <a href="#" class="twitter"><i class="icofont-twitter"></i></a>
            <a href="#" class="facebook"><i class="icofont-facebook"></i></a>
            <a href="#" class="instagram"><i class="icofont-instagram"></i></a>
            <a href="#" class="skype"><i class="icofont-skype"></i></a>
            <a href="#" class="linkedin"><i class="icofont-linkedin"></i></i></a>
        </div>
    </div>
</div>

<!-- ======= Header ======= -->
<header id="header" class="fixed-top">
    <div class="container d-flex ">

        <h1 class="logo mr-auto bg-light"><a href="landingpage.html">SIWIKODE</a></h1>
        <nav class="nav-menu d-none d-lg-block">

            <ul>

                <li class="active"><a href="<?= base_url(); ?>">Home</a></li>
                <li><a href="<?= base_url(); ?>rekreasi">Wisata Rekreasi</a></li>
                <li><a href="<?= base_url(); ?>kuliner">Wisata Kuliner</a></li>
                <li><a href="<?= base_url(); ?>auth/registration">Registrasi</a></li>
                <li><a href="<?= base_url(); ?>siwikode">About</a></li>

            </ul>

        </nav><!-- nav-menu -->

        <a href="<?= base_url(); ?>auth" class="appointment-btn scrollto">Login</a>

    </div>

</header><!-- End Header -->

<body class="bg-gradient-primary">
    <main id="main">
        <!-- ======= Why Us Section ======= -->
        </br></br></br>
        <section id="why-us" class="why-us">
            <br><br>
            <h3 style="text-align: center;">NAMA KELOMPOK</h3>
            <div class="container">
                <div class="card kartu">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="foto">
                                <img src="assets/img/rizqi.jpeg" alt="" width="200" height="180">
                            </div>
                        </div>


                        <div class="col-md-8 kertas-biodata">
                            <div class="biodata">
                                <table width="100%" border="0">
                                    <tbody>
                                        <tr>
                                            <td valign="top">
                                                <table border="0" width="100%" style="padding-left: 2px; padding-right: 10px;">
                                                    <tbody>
                                                        <tr>
                                                            <td width="20%" valign="top" class="textt">Nama
                                                            </td>
                                                            <td width="2%">:</td>
                                                            <td style="color: rgb(118, 157, 29); font-weight:bold">
                                                                Muhammad Rizqi</td>
                                                        </tr>
                                                        <tr>
                                                            <td class="textt">Jenis Kelamin</td>
                                                            <td>:</td>
                                                            <td>Laki-Laki</td>
                                                        </tr>
                                                        <tr>
                                                            <td class="textt">Tempat Lahir</td>
                                                            <td>:</td>
                                                            <td>Jakarta</td>
                                                        </tr>
                                                        <tr>
                                                            <td class="textt">Tanggal Lahir</td>
                                                            <td>:</td>
                                                            <td>07/07/2002</td>
                                                        </tr>
                                                        <tr>
                                                            <td valign="top" class="textt">Prodi</td>
                                                            <td valign="top">:</td>
                                                            <td>Teknik Informatika</td>
                                                        </tr>
                                                        <tr>
                                                            <td valign="top" class="textt">Blog</td>
                                                            <td valign="top">:</td>
                                                            <td>http://www.glowinthedark.my.id/</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            </br></br>
            <div class="container">
                <div class="card kartu">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="foto">
                                <img src="assets/img/wahyu.jpeg" alt="" width="200" height="180">
                            </div>
                        </div>
                        <div class="col-md-8 kertas-biodata">
                            <div class="biodata">
                                <table width="100%" border="0">
                                    <tbody>
                                        <tr>
                                            <td valign="top">
                                                <table border="0" width="100%" style="padding-left: 2px; padding-right: 13px;">
                                                    <tbody>
                                                        <tr>
                                                            <td width="25%" valign="top" class="textt">Nama
                                                            </td>
                                                            <td width="2%">:</td>
                                                            <td style="color: rgb(118, 157, 29); font-weight:bold">
                                                                Wahid Wahyudin</td>
                                                        </tr>
                                                        <tr>
                                                            <td class="textt">Jenis Kelamin</td>
                                                            <td>:</td>
                                                            <td>Laki-Laki</td>
                                                        </tr>
                                                        <tr>
                                                            <td class="textt">Tempat Lahir</td>
                                                            <td>:</td>
                                                            <td>Bogor</td>
                                                        </tr>
                                                        <tr>
                                                            <td class="textt">Tanggal Lahir</td>
                                                            <td>:</td>
                                                            <td>05/02/2000</td>
                                                        </tr>
                                                        <tr>
                                                            <td valign="top" class="textt">Prodi</td>
                                                            <td valign="top">:</td>
                                                            <td>Teknik Informatika</td>
                                                        </tr>
                                                        <tr>
                                                            <td valign="top" class="textt">Blog</td>
                                                            <td valign="top">:</td>
                                                            <td>https://oneshare05.blogspot.com/</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            </br></br>
            <div class="container">
                <div class="card kartu">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="foto">
                                <img src="assets/img/farhan.jpeg" alt="" width="200" height="180">
                            </div>
                        </div>
                        <div class="col-md-8 kertas-biodata">
                            <div class="biodata">
                                <table width="100%" border="0">
                                    <tbody>
                                        <tr>
                                            <td valign="top">
                                                <table border="0" width="100%" style="padding-left: 2px; padding-right: 13px;">
                                                    <tbody>
                                                        <tr>
                                                            <td width="25%" valign="top" class="textt">Nama
                                                            </td>
                                                            <td width="2%">:</td>
                                                            <td style="color: rgb(118, 157, 29); font-weight:bold">
                                                                Muhammad Farhan Aula</td>
                                                        </tr>
                                                        <tr>
                                                            <td class="textt">Jenis Kelamin</td>
                                                            <td>:</td>
                                                            <td>Laki-Laki</td>
                                                        </tr>
                                                        <tr>
                                                            <td class="textt">Tempat Lahir</td>
                                                            <td>:</td>
                                                            <td>Bogor</td>
                                                        </tr>
                                                        <tr>
                                                            <td class="textt">Tanggal Lahir</td>
                                                            <td>:</td>
                                                            <td>24/05/2002</td>
                                                        </tr>
                                                        <tr>
                                                            <td valign="top" class="textt">Prodi</td>
                                                            <td valign="top">:</td>
                                                            <td>Teknik Informatika</td>
                                                        </tr>
                                                        <tr>
                                                            <td valign="top" class="textt">Blog</td>
                                                            <td valign="top">:</td>
                                                            <td>https://farhanaula17.blogspot.com/</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Section -->