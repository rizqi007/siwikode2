<div class="container">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb mt-2">
            <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Registrasi</li>
        </ol>
    </nav>



    <div class="row mt-3">
        <div class="col-md-8">

            <div class="card">
                <div class="card-header">
                    Form Tambah Data Mahasiswa
                </div>
                <div class="card-body">
                    <?php if (validation_errors()) : ?>

                        <div class="alert alert-danger" role="alert">
                            <?= validation_errors(); ?>
                        </div>

                    <?php endif; ?>

                    <form action="" method="post">
                        <div class="form-group">
                            <label for="nama">Nama</label>
                            <input type="text" class="form-control" id="nama" name="nama">
                        </div>
                        <div class="form-group">
                            <label for="nim">NIM</label>
                            <input type="text" class="form-control" id="nim" name="nim">
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" id="email" name="email">
                        </div>
                        <div class="form-group">
                            <label for="jurusan">Jurusan</label>
                            <select class="form-control" id="jurusan" name="jurusan">
                                <option value="Teknik Informatika">Teknik Informatika</option>
                                <option value="Sistem Informasi">Sistem Informasi</option>
                            </select>
                        </div>
                        <button type="submit" name="tambah" class="btn btn-primary float-right" onclick="Swal.fire('Apakah anda yakin?', 'ini akan menghapus semua data anda', 'question');">Tambah Data</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card">
                <ul class="list-group list-group-flush">
                    <div class="card-header">Menu Navigasi</div>
                    <li class="list-group-item"><a href="<?= base_url(); ?>auth">Sudah punya akun? Login!</a> </li>
                    <div class="card-header">SIWIKODE</div>
                </ul>
            </div>

        </div>

    </div>
</div>