<main id="main">
    <!-- ======= Why Us Section ======= -->
    </br></br></br></br></br>
    <div class="container">
        <div class="d-flex justify-content-between">
            <div class="card-block">
                <div class="col-md-auto mb-3">

                    <h2>Mang Engking</h2>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>

                </div>
            </div>
        </div>
        <!--Akhir Comment-->

        <div class="row">
            <div class="col-md-6">
                <div class="card-body">
                    <h5 class="card-title text-danger text-mg">Deskripsi Mang engking</h5>
                    <p class="card-text text-justify"> Engking Sodikin atau yang lebih dikenal dengan Mang Engking, adalah pemilik dari restoran khas bernuansa alam dengan ciri gubug-gubug di atas kolam budidaya udang dan ikan air tawar. Mang Engking berasal dari Tasikmalaya, Jawa Barat. Berawal dari kehidupan yang sangat sederhana, di tahun 1996, Mang Engking dan beberapa anggota keluarganya hijrah ke Yogyakarta untuk mengembangkan keahliannya dalam bidang budidaya udang dan ikan air tawar. Sebelum hijrah, Mang Engking sudah berprofesi sebagai pembudidaya udang dan ikan air tawar sejak tahun 1988. Ilmu budidaya tersebut dia dapat secara turun-menurun dari keluarganya. Namun dari keahliannya tersebut, kebutuhan akan hidup kurang dapat terpenuhi apabila ia tidak keluar dari Tasikmalaya.

                        Di awal 1997, ia mulai membina beberapa petani di sekitar tempat tinggalnya di daerah Sleman, Yogyakarta untuk belajar membudidayakan udang galah yang kemudian hasilnya dipasarkan ke Cilacap. Dikarenakan pembayaran yang tidak lancar, maka Mang Engking beralih memasarkan udang galah tersebut ke Bali sebagai pasokan supermarket dan restoran. Setelah terjadinya tragedi bom Bali I, ia cukup kesulitan memasarkan udang galahnya masuk ke Bali. Selain itu sistem pembayaran dirasa sudah tidak cocok lagi, sehingga pada akhirnya ia mencoba memasarkannya sendiri.<br><br>
                    </p>
                    <p class="text-dark text-mgs">
                        Alamat : Kampus UI Jalan Danau Salam, RW.3, Srengseng Sawah, Kec. Jagakarsa, Kota Jakarta Selatan, Jawa Barat 16424
                    </p>
                </div>


            </div>
            <div class="col-md-6">
                <div class="card-body">
                    <h5 class="card-title text-danger text-mg">Peta Lokasi</h5>
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3965.344853210131!2d106.82941661412195!3d-6.349376295405251!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69ec306e509193%3A0x25a371469eb859e9!2sGubug%20Makan%20Mang%20Engking!5e0!3m2!1sen!2sid!4v1625668923492!5m2!1sen!2sid" width="450" height="600" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>
            </div>
        </div>


        <div class="container">
            <h3>GALERI MANG ENGKING</h3>
            <div class="row ml-4">

                <div class="col-sm-6 col-md-4 grid-costum mt-5">
                    <a href="<?= base_url(); ?>assets/img/kuliner/engking/1.jpeg" data-lightbox="mygallery" data-title="gambar 1"><img class="img-responsive" src="<?= base_url(); ?>assets/img/kuliner/engking/1.jpeg" alt="Image Test"></a>
                </div>

                <div class="col-sm-6 col-md-4 grid-costum mt-5">
                    <a href="<?= base_url(); ?>assets/img/kuliner/engking/2.jpeg" data-lightbox="mygallery" data-title="gambar 2"><img class="img-responsive" src="<?= base_url(); ?>assets/img/kuliner/engking/2.jpeg" alt="Image Test"></a>
                </div>

                <div class="col-sm-6 col-md-4 grid-costum mt-5">
                    <a href="<?= base_url(); ?>assets/img/kuliner/engking/3.jpeg" data-lightbox="mygallery" data-title="gambar 3"><img class="img-responsive" src="<?= base_url(); ?>assets/img/kuliner/engking/3.jpeg" alt="Image Test"></a>
                </div>

                <div class="col-sm-6 col-md-4 grid-costum mt-5">
                    <a href="<?= base_url(); ?>assets/img/kuliner/engking/4.jpeg" data-lightbox="mygallery" data-title="gambar 3"><img class="img-responsive" src="<?= base_url(); ?>assets/img/kuliner/engking/4.jpeg" alt="Image Test"></a>
                </div>

                <div class="col-sm-6 col-md-4 grid-costum mt-5">
                    <a href="<?= base_url(); ?>assets/img/kuliner/engking/5.jpeg" data-lightbox="mygallery" data-title="gambar 3"><img class="img-responsive" src="<?= base_url(); ?>assets/img/kuliner/engking/5.jpeg" alt="Image Test"></a>
                </div>

                <div class="col-sm-6 col-md-4 grid-costum mt-5">
                    <a href="<?= base_url(); ?>assets/img/kuliner/engking/6.jpeg" data-lightbox="mygallery" data-title="gambar 3"><img class="img-responsive" src="<?= base_url(); ?>assets/img/kuliner/engking/6.jpeg" alt="Image Test"></a>
                </div>
            </div>



            <section id="why-us" class="why-us">

                <section class="row">
                    <div class="container">
                        <h3>TESTIMONI</h3>
                        <div class="row">
                            <div class="col-lg-4 d-flex align-items-stretch mt-5">
                                <div class="content">
                                    <h3>Arafah Rianti</h3>
                                    <img class="card-img-top" alt="Bootstrap Thumbnail First" src="<?= base_url(); ?>assets/img/testimoni/arafah.jpeg" />
                                    <br><br>
                                    <p>
                                        Saat berkunjung suasana cafe nya sangat nyaman,pelayannya yang sangat ramah dan harga yang tejangkau
                                        sesuai dengan rasa.
                                    </p>
                                    <div class="text-center">

                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 d-flex align-items-stretch mt-5">
                                <div class="content">
                                    <h3>Mohammad Idris</h3>
                                    <img class="card-img-top" alt="Bootstrap Thumbnail First" src="<?= base_url(); ?>assets/img/testimoni/idris.jpeg" height="170" />
                                    <br><br>
                                    <p>
                                        Nyaman dan pelayanannya sangat ramah.Cafe ini juga menyediakan menu yang bervariatif.
                                    </p>
                                    <div class="text-center">

                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 d-flex align-items-stretch mt-5">
                                <div class="content">
                                    <h3>Warga</h3>
                                    <img class="card-img-top" alt="Bootstrap Thumbnail First" src="<?= base_url(); ?>assets/img/testimoni/warga.jpeg" height=170 />
                                    <br><br>
                                    <p>
                                        Tempat Nya Nyamann Untuk Dijadikan Tempat Kumpul Untuk Bersantaii,Minuman dan Makanannya juga Murah
                                        .
                                    </p>
                                    <div class=" text-center">

                                    </div>
                                </div>
                            </div>

                </section>
            </section>