<main id="main">
    <!-- ======= Why Us Section ======= -->
    </br></br></br></br></br>
    <div class="container">
        <div class="d-flex justify-content-between">
            <div class="card-block">
                <div class="col-md-auto mb-3">

                    <h2>Mang Kabayan</h2>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>

                </div>
            </div>
        </div>
        <!--Akhir Comment-->

        <div class="row">
            <div class="col-md-6">
                <div class="card-body">
                    <h5 class="card-title text-danger text-mg">Deskripsi Mang Kabayan</h5>
                    <p class="card-text text-justify">Sesuai dengan namanya "Mang Kabayan" tentunya sudah tidak asing dengan ikon tokoh dongeng Sunda ini. Kabayan, tokoh humoris yang beristrikan Nyi Iteung dengan latar kehidupan di lembur (kampung). Dan inilah konsep yang diusung oleh rumah makan Mang Kabayang yang menghadirkan aneka pilihan menu makanan khas Sunda. Pemilihan nama Mang Kabayan nggak sembarangan karena mengandung tujuan untuk memperkuat ciri khas Sunda
                    </p>
                    <p>
                        pada restoran ini. Tidak hanya namanya yang menonjolkan khas Sunda, seluruh fasilitasnya pun sengaja
                        didesain bertemakan budaya Sunda. Sehingga konsumen datang ke restoran ini bisa merasakan nuansa Sunda
                        yang kental seperti yang diceritakan dalam dongeng Si Kabayan. Disini banyak fasilitas yang memadai dan
                        tertata rapi.<br><br>
                    </p>
                    <p class="text-dark text-mgs">
                        Alamat : Jalan Margonda Raya No.488, Pondok Cina, Depok, Pondok Cina, Kecamatan Beji, Kota Depok, Jawa Barat 16424
                    </p>
                </div>


            </div>

            <div class="col-md-6">
                <div class="card-body">
                    <h5 class="card-title text-danger text-mg">Peta Lokasi</h5>
                    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15860.933664373342!2d106.833454!3d-6.3638303!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xbc7e07e8cf18cef!2sMang%20Kabayan!5e0!3m2!1sen!2sid!4v1625697265118!5m2!1sen!2sid" width="450" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>
            </div>

        </div>


        <div class="container">
            <h3>GALERI MANG KABAYAN</h3>
            <div class="row ml-4">

                <div class="col-sm-6 col-md-4 grid-costum mt-5">
                    <a href="<?= base_url(); ?>assets/img/kuliner/engking/1.jpeg" data-lightbox="mygallery" data-title="gambar 1"><img class="img-responsive" src="<?= base_url(); ?>assets/img/kuliner/engking/1.jpeg" alt="Image Test"></a>
                </div>

                <div class="col-sm-6 col-md-4 grid-costum mt-5">
                    <a href="<?= base_url(); ?>assets/img/kuliner/engking/2.jpeg" data-lightbox="mygallery" data-title="gambar 2"><img class="img-responsive" src="<?= base_url(); ?>assets/img/kuliner/engking/2.jpeg" alt=" Image Test"></a>
                </div>

                <div class="col-sm-6 col-md-4 grid-costum mt-5">
                    <a href="<?= base_url(); ?>assets/img/kuliner/engking/3.jpeg" data-lightbox="mygallery" data-title="gambar 3"><img class="img-responsive" src="<?= base_url(); ?>assets/img/kuliner/engking/3.jpeg" alt="Image Test"></a>
                </div>

                <div class="col-sm-6 col-md-4 grid-costum mt-5">
                    <a href="<?= base_url(); ?>assets/img/kuliner/engking/4.jpeg" data-lightbox="mygallery" data-title="gambar 3"><img class="img-responsive" src="<?= base_url(); ?>assets/img/kuliner/engking/4.jpeg" alt="Image Test"></a>
                </div>

                <div class="col-sm-6 col-md-4 grid-costum mt-5">
                    <a href="<?= base_url(); ?>assets/img/kuliner/engking/5.jpeg" data-lightbox="mygallery" data-title="gambar 3"><img class="img-responsive" src="<?= base_url(); ?>assets/img/kuliner/engking/5.jpeg" alt="Image Test"></a>
                </div>

                <div class="col-sm-6 col-md-4 grid-costum mt-5">
                    <a href="<?= base_url(); ?>assets/img/kuliner/engking/6.jpeg" data-lightbox="mygallery" data-title="gambar 3"><img class="img-responsive" src="<?= base_url(); ?>assets/img/kuliner/engking/6.jpeg" alt="Image Test"></a>
                </div>
            </div>



            <section id="why-us" class="why-us">

                <section class="row">
                    <div class="container">
                        <h3>TESTIMONI</h3>
                        <div class="row">
                            <div class="col-lg-4 d-flex align-items-stretch mt-5">
                                <div class="content">
                                    <h3>Arafah Rianti</h3>
                                    <img class="card-img-top" alt="Bootstrap Thumbnail First" src="<?= base_url(); ?>assets/img/testimoni/arafah.jpeg" />
                                    <br><br>
                                    <p>
                                        Saat berkunjung suasana cafe nya sangat nyaman,pelayannya yang sangat ramah dan harga yang tejangkau
                                        sesuai dengan rasa.
                                    </p>
                                    <div class="text-center">

                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 d-flex align-items-stretch mt-5">
                                <div class="content">
                                    <h3>Mohammad Idris</h3>
                                    <img class="card-img-top" alt="Bootstrap Thumbnail First" src="<?= base_url(); ?>assets/img/testimoni/idris.jpeg" height="170" />
                                    <br><br>
                                    <p>
                                        Nyaman dan pelayanannya sangat ramah.Cafe ini juga menyediakan menu yang bervariatif.
                                    </p>
                                    <div class="text-center">

                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 d-flex align-items-stretch mt-5">
                                <div class="content">
                                    <h3>Warga</h3>
                                    <img class="card-img-top" alt="Bootstrap Thumbnail First" src="<?= base_url(); ?>assets/img/testimoni/warga.jpeg" height=170 />
                                    <br><br>
                                    <p>
                                        Tempat Nya Nyamann Untuk Dijadikan Tempat Kumpul Untuk Bersantaii,Minuman dan Makanannya juga Murah
                                        .
                                    </p>
                                    <div class=" text-center">

                                    </div>
                                </div>
                            </div>

                </section>
            </section>