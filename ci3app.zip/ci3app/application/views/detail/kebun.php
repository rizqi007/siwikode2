<main id="main">
    <!-- ======= Why Us Section ======= -->
    </br></br></br></br></br>
    <div class="container">
        <div class="d-flex justify-content-between">
            <div class="card-block">
                <div class="col-md-auto mb-3">

                    <h2>Kebun Raya Bogor</h2>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>

                </div>
            </div>
        </div>
        <!--Akhir Comment-->

        <div class="row">
            <div class="col-md-6">
                <div class="card-body">
                    <h5 class="card-title text-danger text-mg">Deskripsi Kebun Raya Bogor</h5>
                    <p class="card-text text-justify">Kebun Raya Bogor pada mulanya merupakan bagian dari 'samida' (hutan buatan atau taman buatan) yang setidaknya telah ada pada pemerintahan Sri Baduga Maharaja (Prabu Siliwangi, 1474-1513) dari Kerajaan Sunda, sebagaimana tertulis dalam prasasti Batutulis. Hutan buatan itu ditujukan untuk keperluan menjaga kelestarian lingkungan sebagai tempat memelihara benih-benih kayu yang langka. Di samping samida itu dibuat pula samida yang serupa di perbatasan Cianjur dengan Bogor (Hutan Ciung Wanara). Hutan ini kemudian dibiarkan setelah Kerajaan Sunda takluk dari Kesultanan Banten, hingga Gubernur Jenderal van der Capellen membangun rumah peristirahatan di salah satu sudutnya pada pertengahan abad ke-18.

                    </p>
                    <p>
                        Pada awal 1800-an Gubernur Jenderal Thomas Stamford Raffles, yang mendiami Istana Bogor dan memiliki minat besar dalam botani, tertarik mengembangkan halaman Istana Bogor menjadi sebuah kebun yang cantik. Dengan bantuan para ahli botani, W. Kent, yang ikut membangun Kew Garden di London, Raffles menyulap halaman istana menjadi taman bergaya Inggris klasik. Inilah awal mula Kebun Raya Bogor dalam bentuknya sekarang.

                        Monumen Olivia Raffles
                        Pada tahun 1814 Olivia Raffles (istri dari Gubernur Jenderal Thomas Stamford Raffles) meninggal dunia karena sakit dan dimakamkan di Batavia.

                        <br><br>
                    </p>
                    <p class="text-dark text-mgs">
                        Alamat : Jl. Ir. H. Juanda No.13, Paledang, Kecamatan Bogor Tengah, Kota Bogor, Jawa Barat 16122
                </div>


            </div>
            <div class="col-md-6">
                <div class="card-body">
                    <h5 class="card-title text-danger text-mg">Peta Lokasi</h5>
                    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15853.583333226128!2d106.7995698!3d-6.5976289!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x75f23c6b45a37ee5!2sBogor%20Botanical%20Gardens!5e0!3m2!1sen!2sid!4v1625698802000!5m2!1sen!2sid" width="450" height="600" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>
            </div>
        </div>


        <div class="container">
            <h3>GALERI KEBUN RAYA BOGOR</h3>
            <div class="row ml-4">

                <div class="col-sm-6 col-md-4 grid-costum mt-5">
                    <a href="<?= base_url(); ?>assets/img/kuliner/engking/1.jpeg" data-lightbox="mygallery" data-title="gambar 1"><img class="img-responsive" src="<?= base_url(); ?>assets/img/kuliner/engking/1.jpeg" alt="Image Test"></a>
                </div>

                <div class="col-sm-6 col-md-4 grid-costum mt-5">
                    <a href="<?= base_url(); ?>assets/img/kuliner/engking/2.jpeg" data-lightbox="mygallery" data-title="gambar 2"><img class="img-responsive" src="<?= base_url(); ?>assets/img/kuliner/engking/2.jpeg" alt="Image Test"></a>
                </div>

                <div class="col-sm-6 col-md-4 grid-costum mt-5">
                    <a href="<?= base_url(); ?>assets/img/kuliner/engking/3.jpeg" data-lightbox="mygallery" data-title="gambar 3"><img class="img-responsive" src="<?= base_url(); ?>assets/img/kuliner/engking/3.jpeg" alt="Image Test"></a>
                </div>

                <div class="col-sm-6 col-md-4 grid-costum mt-5">
                    <a href="<?= base_url(); ?>assets/img/kuliner/engking/4.jpeg" data-lightbox="mygallery" data-title="gambar 3"><img class="img-responsive" src="<?= base_url(); ?>assets/img/kuliner/engking/4.jpeg" alt="Image Test"></a>
                </div>

                <div class="col-sm-6 col-md-4 grid-costum mt-5">
                    <a href="<?= base_url(); ?>assets/img/kuliner/engking/5.jpeg" data-lightbox="mygallery" data-title="gambar 3"><img class="img-responsive" src="<?= base_url(); ?>assets/img/kuliner/engking/5.jpeg" alt="Image Test"></a>
                </div>

                <div class="col-sm-6 col-md-4 grid-costum mt-5">
                    <a href="<?= base_url(); ?>assets/img/kuliner/engking/6.jpeg" data-lightbox="mygallery" data-title="gambar 3"><img class="img-responsive" src="<?= base_url(); ?>assets/img/kuliner/engking/6.jpeg" alt="Image Test"></a>
                </div>
            </div>



            <section id="why-us" class="why-us">

                <section class="row">
                    <div class="container">
                        <h3>TESTIMONI</h3>
                        <div class="row">
                            <div class="col-lg-4 d-flex align-items-stretch mt-5">
                                <div class="content">
                                    <h3>Arafah Rianti</h3>
                                    <img class="card-img-top" alt="Bootstrap Thumbnail First" src="<?= base_url(); ?>assets/img/testimoni/arafah.jpeg" />
                                    <br><br>
                                    <p>
                                        Saat berkunjung suasana cafe nya sangat nyaman,pelayannya yang sangat ramah dan harga yang tejangkau
                                        sesuai dengan rasa.
                                    </p>
                                    <div class="text-center">

                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 d-flex align-items-stretch mt-5">
                                <div class="content">
                                    <h3>Mohammad Idris</h3>
                                    <img class="card-img-top" alt="Bootstrap Thumbnail First" src="<?= base_url(); ?>assets/img/testimoni/idris.jpeg" height="170" />
                                    <br><br>
                                    <p>
                                        Nyaman dan pelayanannya sangat ramah.Cafe ini juga menyediakan menu yang bervariatif.
                                    </p>
                                    <div class="text-center">

                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 d-flex align-items-stretch mt-5">
                                <div class="content">
                                    <h3>Warga</h3>
                                    <img class="card-img-top" alt="Bootstrap Thumbnail First" src="<?= base_url(); ?>assets/img/testimoni/warga.jpeg" height=170 />
                                    <br><br>
                                    <p>
                                        Tempat Nya Nyamann Untuk Dijadikan Tempat Kumpul Untuk Bersantaii,Minuman dan Makanannya juga Murah
                                        .
                                    </p>
                                    <div class=" text-center">

                                    </div>
                                </div>
                            </div>

                </section>
            </section>