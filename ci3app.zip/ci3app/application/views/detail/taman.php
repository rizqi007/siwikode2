<main id="main">
    <!-- ======= Why Us Section ======= -->
    </br></br></br></br></br>
    <div class="container">
        <div class="d-flex justify-content-between">
            <div class="card-block">
                <div class="col-md-auto mb-3">

                    <h2>Taman Wiladatika</h2>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>

                </div>
            </div>
        </div>
        <!--Akhir Comment-->

        <div class="row">
            <div class="col-md-6">
                <div class="card-body">
                    <h5 class="card-title text-danger text-mg">Deskripsi Taman Wiladatika</h5>
                    <p class="card-text text-justify">Taman Rekreasi Wiladatika Cibubur merupakan tempat wisata yang berlokasi di Cimanggis, Depok Jawa Barat. Di sini terdapat Pusat Pendidikan dan Pelatihan Pramuka Nasional (Pusdiklatmas), aula resepsi yang biasa digunakan untuk acara resepsi pernikahan, dan halaman hijau yang biasa di gunakan para pengunjung untuk piknik bersama keluarga, ketika acara besar pramuka biasa digunakan untuk berkemah. Taman Rekreasi ini di resmikan oleh Presiden Soeharto pada tahun 1980 tepatnya pada tanggal 29 Juni.

                    </p>
                    <p>
                        aman rekreasi ini berlokasi di Jalan Jambore nomor 1, Harjamukti, Cimanggis, RT.8, Kota Depok, Jawa Barat 13720. Ia memiliki posisi koordinat GPS 6°22’16”S 106°53’31”E dan terletak dekat dengan Cibubur Junction. Tanggal 14 Agustus 2016 diadakan acara Jambore Nasional (JamNas) ke-10 di Taman Rekreasi Wiladatika Cibubur[3]. Pembukaan acara dibuka oleh Presiden Joko Widodoselaku ketua Majelis Pembimbing Nasional Gerak Pramuka[4]. Acara ini dilaksanakan selama tujuh hari. Acara ini juga diikuti oleh peserta dari seluruh provinsi di Indonesia dengan total peserta sekitar 25.000 anggota Gerak Pramuka[5]. Beberapa judul sinetron seperti Bidadari, Tuyul dan Mbak Yul, Tuyul dan Mba Yul Reborn, Tikus dan Kucing, Samudra Cinta, Anak Band hingga Orang Ketiga tercatat pernah melakukan proses syuting di sini.



                        <br><br>
                    </p>
                    <p class="text-dark text-mgs">
                        Alamat : Jl. Jambore No.1, Harjamukti, Kec. Cimanggis, Kota Depok, Jawa Barat 13720
                </div>


            </div>
            <div class="col-md-6">
                <div class="card-body">
                    <h5 class="card-title text-danger text-mg">Peta Lokasi</h5>
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15860.736908139797!2d106.88457226977539!3d-6.3702!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69eca341d5feeb%3A0x1475ebc18101ced!2sTaman%20Rekreasi%20Wiladatika!5e0!3m2!1sen!2sid!4v1625699004667!5m2!1sen!2sid" width="450" height="600" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>
            </div>
        </div>


        <div class="container">
            <h3>GALERI TAMAN WILADATIKA</h3>
            <div class="row ml-4">

                <div class="col-sm-6 col-md-4 grid-costum mt-5">
                    <a href="<?= base_url(); ?>assets/img/kuliner/engking/1.jpeg" data-lightbox="mygallery" data-title="gambar 1"><img class="img-responsive" src="<?= base_url(); ?>assets/img/kuliner/engking/1.jpeg" alt="Image Test"></a>
                </div>

                <div class="col-sm-6 col-md-4 grid-costum mt-5">
                    <a href="<?= base_url(); ?>assets/img/kuliner/engking/2.jpeg" data-lightbox="mygallery" data-title="gambar 2"><img class="img-responsive" src="<?= base_url(); ?>assets/img/kuliner/engking/2.jpeg" alt="Image Test"></a>
                </div>

                <div class="col-sm-6 col-md-4 grid-costum mt-5">
                    <a href="<?= base_url(); ?>assets/img/kuliner/engking/3.jpeg" data-lightbox="mygallery" data-title="gambar 3"><img class="img-responsive" src="<?= base_url(); ?>assets/img/kuliner/engking/3.jpeg" alt="Image Test"></a>
                </div>

                <div class="col-sm-6 col-md-4 grid-costum mt-5">
                    <a href="<?= base_url(); ?>assets/img/kuliner/engking/4.jpeg" data-lightbox="mygallery" data-title="gambar 3"><img class="img-responsive" src="<?= base_url(); ?>assets/img/kuliner/engking/4.jpeg" alt="Image Test"></a>
                </div>

                <div class="col-sm-6 col-md-4 grid-costum mt-5">
                    <a href="<?= base_url(); ?>assets/img/kuliner/engking/5.jpeg" data-lightbox="mygallery" data-title="gambar 3"><img class="img-responsive" src="<?= base_url(); ?>assets/img/kuliner/engking/5.jpeg" alt="Image Test"></a>
                </div>

                <div class="col-sm-6 col-md-4 grid-costum mt-5">
                    <a href="<?= base_url(); ?>assets/img/kuliner/engking/6.jpeg" data-lightbox="mygallery" data-title="gambar 3"><img class="img-responsive" src="<?= base_url(); ?>assets/img/kuliner/engking/6.jpeg" alt="Image Test"></a>
                </div>
            </div>



            <section id="why-us" class="why-us">

                <section class="row">
                    <div class="container">
                        <h3>TESTIMONI</h3>
                        <div class="row">
                            <div class="col-lg-4 d-flex align-items-stretch mt-5">
                                <div class="content">
                                    <h3>Arafah Rianti</h3>
                                    <img class="card-img-top" alt="Bootstrap Thumbnail First" src="<?= base_url(); ?>assets/img/testimoni/arafah.jpeg" />
                                    <br><br>
                                    <p>
                                        Saat berkunjung suasana cafe nya sangat nyaman,pelayannya yang sangat ramah dan harga yang tejangkau
                                        sesuai dengan rasa.
                                    </p>
                                    <div class="text-center">

                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 d-flex align-items-stretch mt-5">
                                <div class="content">
                                    <h3>Mohammad Idris</h3>
                                    <img class="card-img-top" alt="Bootstrap Thumbnail First" src="<?= base_url(); ?>assets/img/testimoni/idris.jpeg" height="170" />
                                    <br><br>
                                    <p>
                                        Nyaman dan pelayanannya sangat ramah.Cafe ini juga menyediakan menu yang bervariatif.
                                    </p>
                                    <div class="text-center">

                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 d-flex align-items-stretch mt-5">
                                <div class="content">
                                    <h3>Warga</h3>
                                    <img class="card-img-top" alt="Bootstrap Thumbnail First" src="<?= base_url(); ?>assets/img/testimoni/warga.jpeg" height=170 />
                                    <br><br>
                                    <p>
                                        Tempat Nya Nyamann Untuk Dijadikan Tempat Kumpul Untuk Bersantaii,Minuman dan Makanannya juga Murah
                                        .
                                    </p>
                                    <div class=" text-center">

                                    </div>
                                </div>
                            </div>

                </section>
            </section>