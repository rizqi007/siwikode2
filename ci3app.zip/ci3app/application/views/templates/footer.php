<div class="container d-md-flex py-4 fixed">
    <div class="mr-md-4 text-center text-md-left">
        <div class="copyright">
            &copy; Copyright <strong><span>Mahasiswa STT Nurul fikri @2020</span></strong>. All Rights
            Reserved
        </div>

    </div>
    <div class="social-links text-center text-md-right pt-3 pt-md-0">
        <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
        <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
        <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
        <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
    </div>
</div>
</footer>
<!-- End Footer -->

<div id="preloader"></div>
<a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

<!-- Vendor JS Files -->
<script src="<?= base_url(); ?>assets/vendor/jquery/jquery.min.js"></script>
<script src="<?= base_url(); ?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?= base_url(); ?>assets/vendor/jquery.easing/jquery.easing.min.js"></script>
<script src="<?= base_url(); ?>assets/vendor/php-email-form/validate.js"></script>
<script src="<?= base_url(); ?>assets/vendor/venobox/venobox.min.js"></script>
<script src="<?= base_url(); ?>assets/vendor/waypoints/jquery.waypoints.min.js"></script>
<script src="<?= base_url(); ?>assets/vendor/counterup/counterup.min.js"></script>
<script src="<?= base_url(); ?>assets/vendor/owl.carousel/owl.carousel.min.js"></script>
<script src="<?= base_url(); ?>assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>

<!-- Template Main JS File -->
<script src="<?= base_url(); ?>assets/js/main.js"></script>
<script src="<?= base_url(); ?>assets/js/sb-admin-2.js"></script>
<script src="<?= base_url(); ?>assets/js/sb-admin-2.min.js"></script>
<script src="<?= base_url(); ?>assets/js/sweetalert2.js"></script>
<script src="<?= base_url(); ?>assets/js/sweetalert2.all.min.js"></script>



</body>

</html>