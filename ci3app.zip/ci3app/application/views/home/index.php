<!-- ======= Hero Section ======= -->
<section id="hero" class="d-flex align-items-center">
    <div class="container">
        <h1>SIWIKODE</h1>
        <h2>Sistem Informasi Wisata Kota Depok</h2>
        <a href="#why-us" class="btn-get-started scrollto">Get Started</a>
    </div>
</section><!-- End Hero -->

<main id="main">


    <!-- ======= Why Us Section ======= -->





    <section id="why-us" class="why-us">
        <div class="container">
            <center>
                <div class="row">
                    <div class="col-md-12">
                        <div class="jumbotron jumbotron-fluid">
                            <div class="container">
                                <h3 class="mb-3">Tentang SIWIKODE</h3>
                                <p class="card-text"><strong>SIWIKODE</strong> adalah salah satu website yang dikembangkan untuk mengenalkan kepada masyarakat tentang wisata rekreasi dan wisata kuliner yang ada di kota depok, memperkenalkan fasilitas-fasilitas yang ada di wisata tersebut sehingga masyarakat bisa mengetahui segala informasi yang ada di wisata tersebut.
                                </p>
                                <p>
                                    Dengan adanya SIWIKODE ini masyarakat lebih mengetahui tentang tempat-tempat wisata yang ada di kota Depok dan menikmati wisata-wisata yang berada dekat dengan daerah masyarakat di kota Depok.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </center>
        </div>



    </section>